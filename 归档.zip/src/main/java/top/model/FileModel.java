package top.model;

import top.tools.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class FileModel {
    private static FileModel instance;
    private HashMap<String, ArrayList> typeMap = new HashMap<String, ArrayList>();
    private HashMap<String, ArrayList> filterFileMap = new HashMap<String, ArrayList>();
    private ArrayList<String> allFiles = new ArrayList<String>();
    private ArrayList<String> delFiles = new ArrayList<String>();
    private ArrayList<String> defaultSelceted = new ArrayList<String>();
    private String savePath = "";   // 选择的文件夹路径
    private int encryFlag = 0;  // 0: md5 1: sha1
    private FileModel(){}

    public HashMap<String, ArrayList> getTypeMap() {
        return typeMap;
    }

    public void setTypeMap(HashMap<String, ArrayList> typeMap) {
        this.typeMap = typeMap;
    }

    public HashMap<String, ArrayList> getFilterFileMap() {
        return filterFileMap;
    }

    public void setFilterFileMap(HashMap<String, ArrayList> filterFileMap) {
        this.filterFileMap = filterFileMap;
    }

    public ArrayList<String> getAllFiles() {
        return allFiles;
    }

    public void setAllFiles(ArrayList<String> allFiles) {
        this.allFiles = allFiles;
    }

    public ArrayList<String> getDelFiles() {
        return delFiles;
    }

    public void setDelFiles(ArrayList<String> delFiles) {
        this.delFiles = delFiles;
    }

    public ArrayList<String> getDefaultSelceted() {
        return defaultSelceted;
    }

    public void setDefaultSelceted(ArrayList<String> defaultSelceted) {
        this.defaultSelceted = defaultSelceted;
    }

    public int getEncryFlag() {
        return encryFlag;
    }

    public void setEncryFlag(int encryFlag) {
        this.encryFlag = encryFlag;
    }

    public static synchronized FileModel getInstance() {
        if (instance == null) {
            instance = new FileModel();
        }
        return instance;
    }

    public void folderChangeHandler(String path) {
        if (path != "") {
            clearSave();
            traverseFolder(path);
        }
    }

    public void clearSave() {
        this.typeMap.clear();
        this.filterFileMap.clear();
        this.allFiles.clear();
        this.delFiles.clear();
        this.defaultSelceted.clear();
    }

    private void traverseFolder(String path) {
        File file = new File(path);
        if (file.exists()) {
            File[] files =  file.listFiles();
            if(files != null && files.length > 0) {
                for (File temp : files) {
                    if (temp.isDirectory()) {
                        traverseFolder(temp.getAbsolutePath());
                    } else {
                        allFiles.add(temp.getAbsolutePath());
                        checkFileType(temp);
                        filterFile(temp);
                    }
                }
            }
        }
    }

    private void checkFileType(File file) {
        String fileName = file.getName();
        if (fileName.length() > 0) {
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex != -1) {
                String suffix = fileName.substring(dotIndex, fileName.length());
                if (!this.typeMap.containsKey(suffix)) {
                    this.typeMap.put(suffix, new ArrayList());
                }
                this.typeMap.get(suffix).add(file.getAbsolutePath());
            } else {
                if (!this.typeMap.containsKey("''")) {
                    this.typeMap.put("''", new ArrayList());
                }
                this.typeMap.get("''").add(file.getAbsolutePath());
            }
        }
    }

    private void filterFile(File file) {
        if (file.exists()) {
            String encryResult = "";
            if (encryFlag == 0) {
                encryResult = Utils.getMD5(file.getAbsolutePath());
            } else {
                encryResult = Utils.getSHA1(file.getAbsolutePath());
            }
            if (encryResult != "") {
                if (!filterFileMap.containsKey(encryResult)) {
                    filterFileMap.put(encryResult, new ArrayList());
                }
                if (filterFileMap.get(encryResult).size() > 0) {
                    defaultSelceted.add(file.getAbsolutePath());
                }
                filterFileMap.get(encryResult).add(file.getAbsolutePath());
            }
        }
    }

}
