package top;

import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXListView;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.util.Callback;
import top.model.FileModel;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class Controller {
    @FXML
    private VBox rootLayout;

    @FXML
    private JFXListView suffixView;
    @FXML
    private JFXListView fileListView;

    private Stage stage;

    public void selectFile(MouseEvent event) {
        DirectoryChooser chooser = new DirectoryChooser();
//        chooser.setInitialDirectory(new File("D:\\"));
        chooser.setTitle("选择文件夹");
        File choosedir = chooser.showDialog(getStage());
        try {
            if (choosedir != null) {
                System.out.println(choosedir.getAbsolutePath());
                String choosePath = choosedir.getAbsolutePath();
                FileModel fileModel = FileModel.getInstance();
                fileModel.folderChangeHandler(choosePath);
                addSuffixItem(fileModel.getTypeMap());
                addFileItem(fileModel.getAllFiles());
            } else {
                System.out.println("没有选择文件夹");
            }
        } catch (Error e) {
            e.printStackTrace();
        }
    }

    public void addSuffixItem(HashMap typeMap) {
        suffixView.getItems().clear();
        suffixView.getItems().add(0, "全部文件");
        suffixView.getItems().add(1, "重复文件");
        suffixView.getItems().add(2, new Separator());
        suffixView.getItems().addAll(typeMap.keySet());
        suffixView.getSelectionModel().selectFirst();
        suffixView.requestFocus();
        suffixView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                System.out.println(observable.getValue() + " get " + newValue);
                if (newValue != null && newValue.getClass().getName() == "java.lang.String") {
                    String select = newValue.toString();
                    if (select == "全部文件") {
                        addFileItem(FileModel.getInstance().getAllFiles());
                    } else if(select == "重复文件") {
                        addFilterFileItem(FileModel.getInstance().getFilterFileMap());
                    }
                }
            }
        });

    }

    public void addFileItem(ArrayList files) {
        fileListView.setItems(FXCollections.observableArrayList(files));
        fileListView.setCellFactory(new Callback<ListView, ListCell>() {
            public ListCell call(ListView param) {
                return new CheckBoxCell();
            }
        });
    }

    public void addOneItem(ArrayList files, int flag) {
        if (flag == 1) {
            fileListView.getItems().add(new Separator());
        }
        fileListView.getItems().addAll(files);
    }

    public void addFilterFileItem(HashMap<String, ArrayList> filterFiles) {
        fileListView.getItems().clear();
        int flag = 0;
        for(String key : filterFiles.keySet()) {
            addOneItem(filterFiles.get(key), flag);
            flag = 1;
        }
        fileListView.setCellFactory(new Callback<ListView, ListCell>() {
            @Override
            public ListCell call(ListView param) {
                return new CheckBoxCell();
            }
        });
    }


    static class CheckBoxCell extends ListCell<Object> {
        @Override
        protected void updateItem(final Object item, boolean empty) {
            super.updateItem(item, empty);
            if (item != null && item.getClass().getName() == "java.lang.String") {
                final JFXCheckBox cb = new JFXCheckBox();
                cb.setText(item.toString());
                ArrayList defaultSelectFiles = FileModel.getInstance().getDefaultSelceted();
                if (defaultSelectFiles.contains(item.toString())) {
                    cb.setSelected(true);
                }
                setGraphic(cb);
                cb.selectedProperty().addListener(new ChangeListener<Boolean>() {
                    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                        System.out.println(item.toString() + " get " + newValue);
                    }
                });
                setVisible(true);
            } else {
                setGraphic(new Separator());
                setVisible(false);
            }
        }
    }

    public Stage getStage() {
        if(stage == null) {
            stage = (Stage) rootLayout.getScene().getWindow();
        }
        return stage;
    }

}
