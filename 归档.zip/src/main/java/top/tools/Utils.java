package top.tools;

import org.apache.commons.codec.digest.DigestUtils;

import java.io.FileInputStream;
import java.io.IOException;

public class Utils {
    public static String getMD5(String path) {
        if (path != "") {
            try {
                return DigestUtils.md5Hex(new FileInputStream(path));
            } catch (IOException e) {
                e.printStackTrace();
                return "";
            }
        } else {
            return "";
        }
    }

    public static String getSHA1(String path) {
        if (path != "") {
            try {
                return DigestUtils.sha1Hex(new FileInputStream(path));
            } catch (IOException e) {
                e.printStackTrace();
                return "";
            }
        } else {
            return "";
        }
    }
}
